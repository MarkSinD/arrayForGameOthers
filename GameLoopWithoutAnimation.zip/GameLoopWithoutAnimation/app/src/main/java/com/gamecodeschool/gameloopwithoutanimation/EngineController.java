package com.gamecodeschool.gameloopwithoutanimation;

public interface EngineController {

    void startNewLevel();
}
