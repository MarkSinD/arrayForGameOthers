package com.gamecodeschool.simplegameloop;

public interface EngineController {

    void startNewLevel();
}
